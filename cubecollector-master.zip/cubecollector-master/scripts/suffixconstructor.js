function Suffix(namespace, bonus, rarity) {
	this.namespace = namespace
	this.bonus = bonus
	this.rarity = rarity
	
	allSuffixes.push(this)
}
allSuffixes = []
